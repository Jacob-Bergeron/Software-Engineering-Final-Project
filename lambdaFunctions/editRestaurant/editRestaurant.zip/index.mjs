import mysql from "mysql";

export const handler = async (event) => {
  var pool = mysql.createPool({
    host: "cs3733db.c5ia86k2epli.us-east-2.rds.amazonaws.com",
    user: "cs3733",
    password: "database720$",
    database: "Tables4u",
  });

  let editRestaurant = (openTime, closeTime) => {
    return new Promise((resolve, reject) => {
      pool.query(
        "INSERT INTO All_Restaurants (openTime, closeTime) VALUES (?, ?)",
        [openTime, closeTime],
        (error, rows) => {
          if (error) {
            return reject(error);
          }
          return resolve(rows);
        }
      );
    });
  };

  const changes = await editRestaurant(event.openTime, event.closeTime);

  // this is what is returned to client
  const response = {
    statusCode: 200,
    result: {
        "openTime" : "17",
        "closeTime" : "22"
    },
  };

  pool.end(); // close DB connections

  return response;
};
